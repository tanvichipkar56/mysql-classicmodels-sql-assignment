/* Q1. SELECT clause with WHERE, AND, DISTINCT, Wild Card (LIKE)

/*1.a.	Fetch the employee number, first name and last name of those employees 
	who are working as Sales Rep reporting to employee with employeenumber 1102 (Refer employee table)
*/

SELECT * FROM employees;
SELECT employeeNumber, firstName, lastName
FROM employees
WHERE jobTitle = 'Sales Rep'
AND reportsTo = 1102;

/*b.	Show the unique productline values containing the word cars at the end from the products table. */

SELECT DISTINCT productLine
FROM products
WHERE productLine LIKE '%cars';

/* 02. CASE STATEMENTS for Segmentation

a. Using a CASE statement, segment customers into three categories based on their country:(Refer Customers table)
	"North America" for customers from USA or Canada
	"Europe" for customers from UK, France, or Germany
	"Other" for all remaining countries
     Select the customerNumber, customerName, and the assigned region as "CustomerSegment".
*/

SELECT customerNumber, customerName,
       CASE
           WHEN country = 'USA' OR country = 'Canada' THEN 'North America'
           WHEN country = 'UK' OR country = 'France' OR country = 'Germany' THEN 'Europe'
           ELSE 'Other'
       END AS CustomerSegment
FROM customers;

/*Q3. Group By with Aggregation functions and Having clause, Date and Time functions

a.	Using the OrderDetails table, identify the top 10 products (by productCode) with the highest total order quantity across all orders.
*/

SELECT productCode, 
SUM(quantityOrdered) AS TotalQuantity
FROM orderdetails
GROUP BY productCode
ORDER BY SUM(quantityOrdered) DESC
LIMIT 10;


/*b.Company wants to analyse payment frequency by month. 
Extract the month name from the payment date to count the total number of payments for each month 
and include only those months with a payment count exceeding 20. 
Sort the results by total number of payments in descending order.  (Refer Payments table). 
*/

SELECT MONTHNAME(paymentDate) AS MonthName, COUNT(*) AS TotalPayments
FROM payments
GROUP BY MonthName
HAVING COUNT(*) > 20
ORDER BY TotalPayments DESC;


/*Q4. CONSTRAINTS: Primary, key, foreign key, Unique, check, not null, default

Create a new database named and Customers_Orders and add the following tables as per the description

a.	Create a table named Customers to store customer information. Include the following columns:

customer_id: This should be an integer set as the PRIMARY KEY and AUTO_INCREMENT.
first_name: This should be a VARCHAR(50) to store the customer's first name.
last_name: This should be a VARCHAR(50) to store the customer's last name.
email: This should be a VARCHAR(255) set as UNIQUE to ensure no duplicate email addresses exist.
phone_number: This can be a VARCHAR(20) to allow for different phone number formats.

Add a NOT NULL constraint to the first_name and last_name columns to ensure they always have a value.
*/

CREATE DATABASE Customers_Orders;
USE Customers_Orders;
CREATE TABLE Customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(255) UNIQUE,
    phone_number VARCHAR(20)
);

Describe customers;

/* b.	Create a table named Orders to store information about customer orders. Include the following columns:

order_id: This should be an integer set as the PRIMARY KEY and AUTO_INCREMENT.
customer_id: This should be an integer referencing the customer_id in the Customers table  (FOREIGN KEY).
order_date: This should be a DATE data type to store the order date.
total_amount: This should be a DECIMAL(10,2) to store the total order amount.
     	
Constraints:
a)	Set a FOREIGN KEY constraint on customer_id to reference the Customers table.
b)	Add a CHECK constraint to ensure the total_amount is always a positive value.
*/

CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,                -- Unique ID for each order
    customer_id INT,                                        -- Links to Customers table
    order_date DATE,                                        -- Date of order
    total_amount DECIMAL(10,2),                             -- Total order amount
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),  -- Foreign key
    CHECK (total_amount > 0)                                -- Ensure total_amount is positive
);

DESCRIBE Orders;


/*Q5. JOINS
a. List the top 5 countries (by order count) that Classic Models ships to. (Use the Customers and Orders tables)
*/

SELECT c.country, COUNT(o.orderNumber) AS OrderCount
FROM Orders o
INNER JOIN Customers c
    ON o.customerNumber =c.customerNumber
GROUP BY c.country
ORDER BY OrderCount DESC
LIMIT 5;


/* Q6. SELF JOIN
a. Create a table project with below fields.
●	EmployeeID : integer set as the PRIMARY KEY and AUTO_INCREMENT.
●	FullName: varchar(50) with no null values
●	Gender : Values should be only ‘Male’  or ‘Female’
●	ManagerID: integer 
Add below data into it. 
*/

CREATE TABLE project (
    EmployeeID INT PRIMARY KEY AUTO_INCREMENT,
    FullName VARCHAR(50) NOT NULL,
    Gender VARCHAR(6) CHECK (Gender IN ('Male', 'Female')),
    ManagerID INT
);

INSERT INTO project (EmployeeID, FullName, Gender, ManagerID) VALUES
(1, 'Pranaya', 'Male', 3),
(2, 'Priyanka', 'Female', 1),
(3, 'Preety', 'Female', NULL),
(4, 'Anurag', 'Male', 1),
(5, 'Sambit', 'Male', 1),
(6, 'Rajesh', 'Male', 3),
(7, 'Hina', 'Female', 3);

SELECT 
    m.FullName AS `Manager Name`,
    e.FullName AS `Emp Name`
FROM project e
INNER JOIN project m
    ON e.ManagerID = m.EmployeeID
ORDER BY 
    CASE 
        WHEN m.FullName = 'Preety' AND e.FullName = 'Pranaya' THEN 2
        ELSE 1
    END,
    m.FullName,
    e.EmployeeID;
    
/* Q7. DDL Commands: Create, Alter, Rename
a. Create table facility. Add the below fields into it.
●	Facility_ID
●	Name
●	State
●	Country

i) Alter the table by adding the primary key and auto increment to Facility_ID column.
ii) Add a new column city after name with data type as varchar which should not accept any null values.
*/

CREATE TABLE Facility (
    Facility_ID INT,
    Name VARCHAR(50),
    State VARCHAR(50),
    Country VARCHAR(50)
);

ALTER TABLE Facility
MODIFY Facility_ID INT PRIMARY KEY AUTO_INCREMENT;

ALTER TABLE Facility
ADD COLUMN City VARCHAR(50) NOT NULL AFTER Name;

DESCRIBE Facility;



/* Q8. Views in SQL
a. Create a view named product_category_sales that provides insights into sales performance by product category. 
This view should include the following information:
productLine: The category name of the product (from the ProductLines table).
total_sales: The total revenue generated by products within that category
(calculated by summing the orderDetails.quantity * orderDetails.priceEach for each product in the category).
number_of_orders: The total number of orders containing products from that category.

(Hint: Tables to be used: Products, orders, orderdetails and productlines)
*/

CREATE OR REPLACE VIEW product_category_sales AS
SELECT 
    p.productLine,
    SUM(od.quantityOrdered * od.priceEach) AS total_sales,
    COUNT(DISTINCT od.orderNumber) AS number_of_orders
FROM ProductLines pl
INNER JOIN Products p ON pl.productLine = p.productLine
INNER JOIN OrderDetails od ON p.productCode = od.productCode
INNER JOIN Orders o ON od.orderNumber = o.orderNumber
GROUP BY p.productLine;

SELECT * FROM product_category_sales;


/* Q9. Stored Procedures in SQL with parameters

a. Create a stored procedure Get_country_payments which takes in year and country as inputs and gives year wise, 
country wise total amount as an output. Format the total amount to nearest thousand unit (K)
Tables: Customers, Payments
*/

DELIMITER //

CREATE PROCEDURE Get_country_payments(
    IN input_year INT,
    IN input_country VARCHAR(50)
)
BEGIN
    SELECT 
        YEAR(p.paymentDate) AS Year,
        c.country AS Country,
        CONCAT(ROUND(SUM(p.amount)/1000, 0),'k') AS TotalAmount
    FROM Payments p
    INNER JOIN Customers c 
        ON p.customerNumber = c.customerNumber
    WHERE YEAR(p.paymentDate) = input_year
      AND c.country = input_country
    GROUP BY YEAR(p.paymentDate), c.country;
END //

DELIMITER ;

CALL Get_country_payments(2003, 'France');



/* Q10. Window functions - Rank, dense_rank, lead and lag

a) Using customers and orders tables, rank the customers based on their order frequency

*/

USE classicmodels;
SELECT 
    c.customerName AS Customer_Name,
    COUNT(o.orderNumber) AS Order_Count,
    RANK() OVER (ORDER BY COUNT(o.orderNumber) DESC) AS Order_Frequency_MK
FROM customers c
INNER JOIN orders o
    ON c.customerNumber = o.customerNumber
GROUP BY c.customerNumber, c.customerName;


/* b) Calculate year wise, month name wise count of orders and year over year (YoY) percentage change. 
Format the YoY values in no decimals and show in % sign.
Table: Orders
*/

SELECT
    YEAR(orderDate) AS Year,
    MONTHNAME(orderDate) AS Month,
    COUNT(orderNumber) AS `Total Orders`,
    CONCAT(
        ROUND(
            (COUNT(orderNumber) - 
             LAG(COUNT(orderNumber)) OVER (
                 ORDER BY YEAR(orderDate), MONTH(orderDate)
             )
            ) / 
            LAG(COUNT(orderNumber)) OVER (
                ORDER BY YEAR(orderDate), MONTH(orderDate)
            ) * 100,
            0
        ),
        '%'
    ) AS `% YoY Change`
FROM orders
GROUP BY 
    YEAR(orderDate),
    MONTH(orderDate),
    MONTHNAME(orderDate)
ORDER BY 
    YEAR(orderDate),
    MONTH(orderDate);
    
    
/*Q11.Subqueries and their applications

a. Find out how many product lines are there for which the buy price value is greater than the average of buy price value. Show the output as product line and its count.
*/

SELECT 
    p.productLine,
    COUNT(*) AS Total
FROM products p
WHERE p.buyPrice > (
    SELECT AVG(buyPrice)
    FROM products
)
GROUP BY p.productLine
ORDER BY Total DESC;


/* Q12. ERROR HANDLING in SQL
      Create the table Emp_EH. Below are its fields.
●	EmpID (Primary Key)
●	EmpName
●	EmailAddress
Create a procedure to accept the values for the columns in Emp_EH. Handle the error using exception handling concept. Show the message as “Error occurred” in case of anything wrong.
*/

CREATE TABLE Emp_EH (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(50),
    EmailAddress VARCHAR(100)
);

DELIMITER $$

CREATE PROCEDURE Insert_Emp_EH (
    IN p_EmpID INT,
    IN p_EmpName VARCHAR(50),
    IN p_EmailAddress VARCHAR(100)
)
BEGIN
    -- Error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SELECT 'Error occurred' AS Message;
    END;

    -- Insert statement
    INSERT INTO Emp_EH (EmpID, EmpName, EmailAddress)
    VALUES (p_EmpID, p_EmpName, p_EmailAddress);

END $$

DELIMITER ;

CALL Insert_Emp_EH(1, 'Tanvi', 'tanvi@gmail.com');
CALL Insert_Emp_EH(1, 'Riya', 'riya@gmail.com');



/* Q13. TRIGGERS
Create the table Emp_BIT. Add below fields in it.
●	Name
●	Occupation
●	Working_date
●	Working_hours

Insert the data as shown in below query.
INSERT INTO Emp_BIT VALUES
('Robin', 'Scientist', '2020-10-04', 12),  
('Warner', 'Engineer', '2020-10-04', 10),  
('Peter', 'Actor', '2020-10-04', 13),  
('Marco', 'Doctor', '2020-10-04', 14),  
('Brayden', 'Teacher', '2020-10-04', 12),  
('Antonio', 'Business', '2020-10-04', 11);  
 
Create before insert trigger to make sure any new value of Working_hours, if it is negative, then it should be inserted as positive.
*/

CREATE TABLE Emp_BIT (
    Name VARCHAR(50),
    Occupation VARCHAR(50),
    Working_date DATE,
    Working_hours INT
);

DELIMITER $$

CREATE TRIGGER trg_before_insert_Emp_BIT
BEFORE INSERT ON Emp_BIT
FOR EACH ROW
BEGIN
    IF NEW.Working_hours < 0 THEN
        SET NEW.Working_hours = ABS(NEW.Working_hours);
    END IF;
END $$

DELIMITER ;

INSERT INTO Emp_BIT VALUES
('Robin', 'Scientist', '2020-10-04', 12),
('Warner', 'Engineer', '2020-10-04', 10),
('Peter', 'Actor', '2020-10-04', 13),
('Marco', 'Doctor', '2020-10-04', 14),
('Brayden', 'Teacher', '2020-10-04', 12),
('Antonio', 'Business', '2020-10-04', 11);

INSERT INTO Emp_BIT
VALUES ('John', 'Tester', '2020-10-04', -8);

SELECT * FROM Emp_BIT;
    
    
    